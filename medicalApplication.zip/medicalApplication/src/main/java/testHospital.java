// Douglas Wiggins
// CS-320-Q5397
// 05/31/2020

// The objective of this code is to one approach to software testing at the same time 
// implement best practices that was learn in previous modules.
/*
 */



import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({})
public class testHospital {

	// This section of code is test hospital preferences.

	@Test
    public void testAllergy(){
        Allergy allergy =new Allergy("Dummy_Name");
        allergy.setName("Dummy_Value_Name");
        assertEquals("Allergy Dummy_Value_Name", allergy.toString());
    }

    @Test
    public void testDoctor(){
        Doctor doctor = new Doctor("Doctor_Name","Doctor_id");
        assertEquals("Doctor Name:Doctor_Name ID: Doctor_id",doctor.toString());
    }

    @Test
    public void testEmployee(){
        Employee employee = new Employee("Emp_Name","Emp_Id");
        assertEquals("Open",employee.getPassword());
    }

    @Test
    public void testMedicalRecord(){
        Patient patient = new Patient("Patient_Name","Patient_Id");
        MedicalRecord medicalRecord = new MedicalRecord(patient);
        assertEquals("Patient_Name",medicalRecord.getPatient().getName());

    }

    @Test
    public void testMedication(){
        Medication medication = new Medication("Med_name","Start_Date","End_Date","dose");
        assertEquals("Medication:Med_name Start Date: Start_Date End Date: End_Date Dose: dose",medication.toString());
    }

    @Test
    public void testPatient(){
        Patient patient = new Patient("Patient_Name","Patient_Id");
        assertEquals("Patient Name: Patient_Name ID: Patient_Id",patient.toString());
    }

    @Test
    public void testPatientHistory(){
        PatientHistory patientHistory= new PatientHistory();
        Treatment treatment = new Treatment("Dummy_date","Dummy_diagnose","dummy_description");
        Medication medication = new Medication("Med_name","Start_Date","End_Date","dose");
        Allergy allergy =new Allergy("Dummy_Name");
        patientHistory.addTreatment(treatment);
        patientHistory.addAllergy(allergy);
        patientHistory.addMedication(medication);

        assertEquals("Medication:Med_name Start Date: Start_Date End Date: End_Date Dose: dose",patientHistory.getAllMedications().get(0).toString());

    }

    @Test
    public void testTreatement(){
        Treatment treatment = new Treatment("Dummy_date","Dummy_diagnose","dummy_description");
        assertEquals("Treatment:  Date: Dummy_date Diagnose: Dummy_diagnose",treatment.toString());

    }
}

