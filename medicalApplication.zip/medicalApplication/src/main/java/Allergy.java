
public class Allergy {

}
